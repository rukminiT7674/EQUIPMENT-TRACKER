import "./App.css";
import { useEffect, useState } from "react";
import { getEquipment } from "./api";
import EquipmentForm from "./components/EquipmentForm";
import EquipmentTable from "./components/EquipmentTable";

function App() {
  const [equipment, setEquipment] = useState([]);
  const [selected, setSelected] = useState(null);

  const loadData = async () => {
    const data = await getEquipment();
    setEquipment(data);
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="container">
      <h2>Equipment Tracker</h2>

      <EquipmentForm
        refresh={loadData}
        selected={selected}
        clearSelection={() => setSelected(null)}
      />

      <EquipmentTable
        equipment={equipment}
        refresh={loadData}
        onEdit={setSelected}
      />
    </div>
  );
}

export default App;
