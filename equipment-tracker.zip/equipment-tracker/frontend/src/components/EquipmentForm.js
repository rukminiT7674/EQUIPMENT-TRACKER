import { useEffect, useState } from "react";
import { addEquipment, updateEquipment } from "../api";

export default function EquipmentForm({ refresh, selected, clearSelection }) {
  const [form, setForm] = useState({
    name: "",
    type: "Machine",
    status: "Active",
    lastCleaned: ""
  });

  useEffect(() => {
    if (selected) {
      setForm({
        name: selected.name,
        type: selected.type,
        status: selected.status,
        lastCleaned: selected.lastCleaned || ""
      });
    }
  }, [selected]);

  const submit = async (e) => {
    e.preventDefault();

    try {
      if (selected) {
        console.log("UPDATING ID:", selected.id);
        await updateEquipment(selected.id, form);
        clearSelection();
      } else {
        await addEquipment(form);
      }

      setForm({
        name: "",
        type: "Machine",
        status: "Active",
        lastCleaned: ""
      });

      refresh();
    } catch (err) {
      console.error("SUBMIT ERROR:", err);
      alert("Update failed. Check console.");
    }
  };

  return (
    <form onSubmit={submit}>
      <input
        placeholder="Name"
        value={form.name}
        required
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />

      <select
        value={form.type}
        onChange={(e) => setForm({ ...form, type: e.target.value })}
      >
        <option>Machine</option>
        <option>Vessel</option>
        <option>Tank</option>
        <option>Mixer</option>
      </select>

      <select
        value={form.status}
        onChange={(e) => setForm({ ...form, status: e.target.value })}
      >
        <option>Active</option>
        <option>Inactive</option>
        <option>Under Maintenance</option>
      </select>

      <input
        type="date"
        value={form.lastCleaned}
        onChange={(e) =>
          setForm({ ...form, lastCleaned: e.target.value })
        }
      />

      <button type="submit">
        {selected ? "Update" : "Add"}
      </button>
    </form>
  );
}
