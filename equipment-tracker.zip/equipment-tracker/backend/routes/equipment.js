const express = require("express");
const db = require("../db");

const router = express.Router();

/**
 * GET all equipment
 */
router.get("/", (req, res) => {
  db.query("SELECT * FROM equipment", (err, results) => {
    if (err) {
      console.error("DB ERROR:", err);
      return res.status(500).json({ error: "Database error" });
    }

    // map snake_case -> camelCase
    const formatted = results.map(row => ({
      id: row.id,
      name: row.name,
      type: row.type,
      status: row.status,
      lastCleaned: row.last_cleaned
    }));

    res.json(formatted);
  });
});

/**
 * ADD equipment
 */
router.post("/", (req, res) => {
  const { name, type, status, lastCleaned } = req.body;

  const sql =
    "INSERT INTO equipment (name, type, status, last_cleaned) VALUES (?, ?, ?, ?)";

  db.query(sql, [name, type, status, lastCleaned], (err, result) => {
    if (err) {
      console.error("INSERT ERROR:", err);
      return res.status(500).json({ error: "Insert failed" });
    }

    res.json({
      id: result.insertId,
      name,
      type,
      status,
      lastCleaned
    });
  });
});

/**
 * UPDATE equipment
 */
router.put("/:id", (req, res) => {
  const { name, type, status, lastCleaned } = req.body;

  const sql =
    "UPDATE equipment SET name=?, type=?, status=?, last_cleaned=? WHERE id=?";

  db.query(
    sql,
    [name, type, status, lastCleaned, req.params.id],
    (err) => {
      if (err) {
        console.error("UPDATE ERROR:", err);
        return res.status(500).json({ error: "Update failed" });
      }

      res.json({ message: "Updated" });
    }
  );
});

/**
 * DELETE equipment
 */
router.delete("/:id", (req, res) => {
  db.query(
    "DELETE FROM equipment WHERE id=?",
    [req.params.id],
    (err) => {
      if (err) {
        console.error("DELETE ERROR:", err);
        return res.status(500).json({ error: "Delete failed" });
      }

      res.json({ message: "Deleted" });
    }
  );
});

module.exports = router;
