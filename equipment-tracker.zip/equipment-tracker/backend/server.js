const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// 🔍 health check
app.get("/health", (req, res) => {
  res.send("OK");
});

// 🔍 try loading routes safely
try {
  const equipmentRoutes = require("./routes/equipment");
  app.use("/api/equipment", equipmentRoutes);
  console.log("Routes attached");
} catch (err) {
  console.error("Failed to load routes:", err);
}

const PORT = 5000;

app.listen(PORT, "127.0.0.1", () => {
  console.log(`Express server listening on port ${PORT}`);
});
